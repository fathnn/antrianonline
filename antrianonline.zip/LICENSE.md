# Copyright (c) 2021 - Indra Styawantoro. All rights reserved.


# Permissions

- Modification
- Distribution
- Private use


# Limitations

- Commercial use
- Liability
- Warranty
